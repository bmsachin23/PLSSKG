import csv
import numpy as np


noise = np.random.normal(1.55, 5.4, 60000)
print(noise)
